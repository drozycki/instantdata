function r(e){return new Worker(""+new URL("../workers/sqliteWorker-Bhh1e9RW.js",import.meta.url).href,{type:"module",name:e?.name})}export{r as default};
